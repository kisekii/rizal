package com.example.biadatadiri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void email(View view) {
        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setData(Uri.parse("mailto:drgnby2431@gmail.com"));
        startActivity(intent);


    }

    public void cellphone(View view){
        Uri uri = Uri.parse("tel:081336400499");
        Intent it = new Intent( Intent.ACTION_VIEW, uri);
        startActivity(it);



    }

    public void showmap(View view) {

        Intent intent = new Intent();
        intent.setAction(intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setData(Uri.parse("https://maps.app.goo.gl/4UxtxXvnG9JTntzj8"));
        startActivity(intent);

    }
}